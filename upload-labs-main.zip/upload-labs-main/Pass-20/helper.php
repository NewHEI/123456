<?php
if($_GET['action'] == 'get_prompt'){
    echo 'Pass-20来源于CTF，请审计代码！';
}
?>